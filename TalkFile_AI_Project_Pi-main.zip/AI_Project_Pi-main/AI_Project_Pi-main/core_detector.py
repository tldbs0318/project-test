# core_detector.py
import numpy as np
import cv2
import config
from hailo_platform import VDevice, HEF, ConfigureParams, InferVStreams
from bytetracker import BYTETracker

# ==========================================================
# [MAIN 호환용 래퍼 클래스] : main.py를 수정하지 않기 위한 가짜 텐서 구조
# ==========================================================
class MockTensor:
    def __init__(self, data): 
        self.data = data
    def cpu(self): 
        return self
    def numpy(self): 
        return self.data
    def int(self): 
        return self
    def tolist(self): 
        return self.data

class MockBoxes:
    def __init__(self, xyxy, track_ids, class_ids):
        self.xyxy = MockTensor(xyxy)
        # 💡 [크래시 방지] None일 때는 래퍼 객체로 감싸지 않고 원시 None을 주어야 main.py의 필터링 조건문이 올바르게 작동합니다.
        self.id = MockTensor(track_ids) if track_ids is not None else None
        self.cls = MockTensor(class_ids) if class_ids is not None else None

class MockResult:
    def __init__(self, boxes):
        self.boxes = boxes

# ==========================================================
# [HAILO DETECTOR ENGINE]
# ==========================================================
class DetectionEngine:
    """라즈베리파이 5 + AI HAT+ 환경에서 최고의 FPS를 보장하는 가속 엔진 클래스"""
    
    def __init__(self):
        print("[*] [하드웨어] Hailo NPU 하드웨어 가속기 초기화 및 모델 로딩 중...")
        self.target = VDevice()
        self.hef = HEF(config.VEHICLE_MODEL_HEF)

        from hailo_platform import HailoStreamInterface, InputVStreamParams, OutputVStreamParams

        self.configure_params = ConfigureParams.create_from_hef(hef=self.hef, interface=HailoStreamInterface.PCIe)
        self.network_group = self.target.configure(self.hef, self.configure_params)[0]
        
        #self.configure_params = ConfigureParams.get_default_config(self.hef)
        #self.network_group = self.target.configure(self.hef, self.configure_params)[0]
        #self.network_group_params = self.network_group.create_params()
        
        # 💡 [성능 최적화] 매 프레임 가속기를 껐다 켜는 지연(Overhead)을 막기 위해 컨텍스트를 미리 상시 활성화합니다.
        self.active_context = self.network_group.activate(self.network_group_params)
        self.active_context.__enter__()
        
        #self.pipeline_context = InferVStreams(self.network_group, self.network_group_params)
        input_vstreams_params = InputVStreamParams.make(self.network_group)
        output_vstreams_params = OutputVStreamParams.make(self.network_group)
        self.pipeline_context = InferVStreams(self.network_group, input_vstreams_params, output_vstreams_params)
        self.infer_pipeline = self.pipeline_context.__enter__()
        
        # 독립형 ByteTrack 초기화
        self.tracker = BYTETracker(track_thresh=config.VEHICLE_CONF, track_buffer=30, match_thresh=0.8)
        self._class_names = {0: 'person', 1: 'bicycle', 2: 'car', 3: 'motorcycle', 5: 'bus', 7: 'truck'}

    def get_vehicle_results(self, frame):
        """Hailo NPU에서 추론 후 ByteTrack을 거쳐 main.py와 호환되는 객체를 반환합니다."""
        h_img, w_img = frame.shape[:2]
        
        # 1. 모델 입력 크기(320x320)에 맞게 프레임 리사이즈 및 전처리
        input_size = config.INFERENCE_SIZE
        resized_frame = cv2.resize(frame, (input_size, input_size))
        input_data = {self.hef.get_input_vstream_infos()[0].name: np.expand_dims(resized_frame, axis=0)}

        # 2. 💡 [성능 최적화] 미리 오픈된 파이프라인 스트림을 활용해 즉시 비동기/동기 추론 처리 (최대 속도 확보)
        raw_outputs = self.infer_pipeline.infer(input_data)
        
        # 3. 후처리 및 데이터 파싱
        detections = [] 
        output_name = self.hef.get_output_vstream_infos()[0].name
        raw_vstream_data = raw_outputs[output_name][0]

        # 객체 파싱 루프 (Hailo NMS 레이어 출력 매칭)
        for pred in raw_vstream_data:
            ymin, xmin, ymax, xmax, score, class_id = pred[:6]
            if score < config.VEHICLE_CONF or int(class_id) not in config.VEHICLE_CLASSES:
                continue
            
            # 메인 루프 해상도(640x360)에 맞게 픽셀 좌표 복원
            x1, y1 = int(xmin * w_img), int(ymin * h_img)
            x2, y2 = int(xmax * w_img), int(ymax * h_img)
            detections.append([x1, y1, x2, y2, score, int(class_id)])

        # 프레임 내에 검출된 사물이 하나도 없다면 원시 None 구조 즉시 리턴
        if len(detections) == 0:
            return [MockResult(boxes=MockBoxes(np.empty((0, 4)), None, None))]

        # 4. ByteTrack 업데이트 및 추적 대상 추출
        online_targets = self.tracker.update(np.array(detections))
        
        xyxy_list, track_ids, class_ids = [], [], []
        for t in online_targets:
            tlbr = t.tlbr  # [x1, y1, x2, y2]
            
            # 💡 [안정성 강화] 패키지 버전에 따라 STrack에 class_id가 없는 현상을 예방하는 방어적 IoU 매칭
            if hasattr(t, 'class_id') and t.class_id is not None:
                best_class_id = t.class_id
            else:
                best_class_id = 0  # 매칭 실패 시 기본값 (person)
                max_iou = -1
                tx1, ty1, tx2, ty2 = tlbr
                for det in detections:
                    dx1, dy1, dx2, dy2, _, d_cls = det
                    inter_x1 = max(tx1, dx1)
                    inter_y1 = max(ty1, dy1)
                    inter_x2 = min(tx2, dx2)
                    inter_y2 = min(ty2, dy2)
                    inter_w = max(0, inter_x2 - inter_x1)
                    inter_h = max(0, inter_y2 - inter_y1)
                    inter_area = inter_w * inter_h
                    union_area = (tx2 - tx1) * (ty2 - ty1) + (dx2 - dx1) * (dy2 - dy1) - inter_area
                    iou = inter_area / union_area if union_area > 0 else 0
                    if iou > max_iou:
                        max_iou = iou
                        best_class_id = d_cls

            xyxy_list.append(tlbr)
            track_ids.append(t.track_id)
            class_ids.append(best_class_id)
            
        # 💡 [크래시 방지] 추적 유지 중인 타겟이 일시적으로 0개가 되었을 때 크래시 예방
        if not track_ids:
            return [MockResult(boxes=MockBoxes(np.empty((0, 4)), None, None))]

        # 5. main.py 연동 인터페이스로 데이터 패킹 포워딩
        return [MockResult(boxes=MockBoxes(np.array(xyxy_list), track_ids, class_ids))]

    @property
    def vehicle_names(self):
        return self._class_names

    def __del__(self):
        """인스턴스 소멸 시 가속기 하드웨어 자원을 안전하게 시스템에 반환합니다."""
        try:
            if hasattr(self, 'pipeline_context'):
                self.pipeline_context.__exit__(None, None, None)
            if hasattr(self, 'active_context'):
                self.active_context.__exit__(None, None, None)
            print("[*] Hailo NPU 자원이 정상적으로 안전 해제되었습니다.")
        except Exception:
            pass
