# 🎒 AI 기반 스마트 백팩 안전 보조 시스템 (라즈베리파이 5 + Hailo-8L NPU)


## 1.: 가속기 드라이버 및 소프트웨어 설치 (최초 1회)
라즈베리파이 화면 좌측 상단의 검은색 모니터 모양 아이콘(**터미널**)을 클릭해 창을 엽니다.

```bash
# 1. 시스템 패키지 리스트 최신화 및 업데이트 
sudo apt update && sudo apt upgrade -y

# 2. Hailo NPU 실행을 위한 핵심 드라이버 및 도구 통합 설치
sudo apt install hailo-all -y

# 3. 설치된 드라이버를 시스템에 반영하기 위해 재부팅 진행
sudo reboot
```

재부팅이 완료되면 터미널을 다시 열고 아래 명령어를 입력하여 NPU가 잘 인지되었는지 검증합니다.
```bash
hailortcli showcase
```
화면에 하드웨어 사양 정보가 정상적으로 출력된다면 가속기 준비가 완료된 것입니다.

---

## 2. NPU 상속형 가상환경 구축 및 패키지 세팅
GitHub에서 다운로드한 프로젝트 폴더(`AI_Project_Pi`)로 진입합니다. 폴더 빈 곳에서 마우스 우클릭을 한 뒤 **[Open in Terminal] (터미널에서 열기)**을 선택합니다. 

검은색 창이 나타나면 아래 명령어를 순서대로 입력하세요.

```bash
# 1. 헤일로 NPU 기본 라이브러리를 이어받는 가상환경 생성 (★시스템 패키지 포함 플래그 필수)
python3 -m venv --system-site-packages venv

# 2. 가상환경 활성화 (정상적으로 켜지면 터미널 창 맨 왼쪽에 (venv) 라고 표시됩니다)
source venv/bin/activate

# 3. 프로젝트 구동에 필요한 필수 패키지 및 독립형 트래커 설치
pip install opencv-python numpy bytetracker
```

---

## 3. 검증 완료된 공식 HEF 모델 파일 다운로드
NPU 칩이 사람, 자전거, 차량 등을 실시간으로 인지할 수 있도록 훈련된 라즈베리파이 공식 YOLOv8n 실행 파일(`.hef`)을 받아옵니다. 가상환경이 켜진 터미널 창에 그대로 아래 명령어를 입력하세요.

```bash
wget [https://raw.githubusercontent.com/raspberrypi/rpi-vision/main/hailo/yolov8n_hailo8l.hef](https://raw.githubusercontent.com/raspberrypi/rpi-vision/main/hailo/yolov8n_hailo8l.hef) -O yolov8n.hef
```
다운로드가 완료되면 폴더 내부에 `yolov8n.hef` 파일이 생성된 것을 볼 수 있습니다.

---

## 🏃‍♂️ 5단계: 실시간 카메라 연동 구동 (최종 현장 적용)
모든 세팅이 끝났습니다. 터미널 창에 아래 명령어를 입력하여 스마트 백팩에 장착된 카메라 모듈 3 와이드 렌즈의 실시간 입력 화면으로 시스템을 즉시 가동합니다.

```bash
python main.py
```
* **동작 확인:** 화면에 실시간 카메라 영상이 가동되며 파란색 ROI ZONE 가이드라인이 표시됩니다.
* 후방에서 차량이나 보행자가 관심 영역 안으로 접근하면 상태를 판별하여 객체 상자 색상이 **초록색(안전) ➡️ 노란색(주의) ➡️ 빨간색(위험)**으로 변경되며 터미널 창에 실시간 경고 로그(TTC 초 단위)가 출력됩니다.
* 시스템을 종료하려면 화면 창을 선택한 상태에서 키보드 **`q`** 키를 누르면 안전하게 꺼집니다.